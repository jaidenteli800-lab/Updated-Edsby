import Foundation

struct DCDSBProfile: Codable, Identifiable {
    let id: String
    let displayName: String
    let email: String?
    let schoolName: String?
    let role: String?
}

struct DCDSBClass: Codable, Identifiable {
    let id: String
    let name: String
    let subject: String?
    let room: String?
    let teacher: DCDSBPerson?
    let students: [DCDSBPerson]
}

struct DCDSBPerson: Codable, Identifiable {
    let id: String
    let displayName: String
    let email: String?
    let avatarURL: URL?
}

struct DCDSBAssignment: Codable, Identifiable {
    let id: String
    let title: String
    let courseName: String
    let dueDate: Date?
    let completed: Bool
}

struct DCDSBAnnouncement: Codable, Identifiable {
    let id: String
    let title: String
    let body: String
    let date: Date?
}
