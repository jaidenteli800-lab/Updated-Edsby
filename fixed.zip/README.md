# DCDSB Fresh

A modern SwiftUI front end for DCDSB/Edsby-style school data.

## Authentication

The app is structured around Microsoft Entra ID / OAuth 2.0 Authorization Code + PKCE. It intentionally does **not** collect DCDSB passwords.

Before production use, replace the placeholder `clientID` and `redirectURI` with an app registration owned/approved for this app. The Edsby client ID and callback URL from an existing Edsby integration should not be reused as if they belonged to this app.

The authentication layer is isolated in `Services/DCDSBAuthorization.swift`. The UI uses `DCDSBSession` so the rest of the app can work with real API data once an approved API/integration endpoint is available.

## Data integration

`Services/DCDSBAPI.swift` contains the typed API client and models for:
- profile
- courses/classes
- teachers
- classmates
- assignments
- announcements
- timetable

Set the API base URL in `AppConfig.swift` to the approved DCDSB service.

Do not scrape private Edsby pages or copy session cookies into another application unless DCDSB/Edsby explicitly permits that integration.

## Build

Open `DCDSBFresh.xcodeproj` in Xcode 16+ and run on iOS 17+.

For GitHub Actions, see `.github/workflows/build.yml`.
