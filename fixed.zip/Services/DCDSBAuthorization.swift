import AuthenticationServices
import CryptoKit
import Foundation

@MainActor
final class DCDSBAuthorization: NSObject, ObservableObject {
    @Published private(set) var accessToken: String?
    private var session: ASWebAuthenticationSession?

    func signIn() async throws {
        guard AppConfig.clientID != "REPLACE_WITH_YOUR_APPROVED_APP_CLIENT_ID" else {
            throw AuthError.appNotConfigured
        }

        let verifier = Self.randomString(length: 64)
        let challenge = Self.base64URL(SHA256.hash(data: Data(verifier.utf8)))

        var components = URLComponents(
            string: "https://login.microsoftonline.com/\(AppConfig.tenantID)/oauth2/v2.0/authorize"
        )!
        components.queryItems = [
            URLQueryItem(name: "client_id", value: AppConfig.clientID),
            URLQueryItem(name: "response_type", value: "code"),
            URLQueryItem(name: "redirect_uri", value: AppConfig.redirectURI),
            URLQueryItem(name: "response_mode", value: "query"),
            URLQueryItem(name: "scope", value: "openid profile offline_access"),
            URLQueryItem(name: "code_challenge", value: challenge),
            URLQueryItem(name: "code_challenge_method", value: "S256"),
            URLQueryItem(name: "state", value: Self.randomString(length: 32))
        ]

        guard let url = components.url else { throw AuthError.invalidURL }

        let callback = try await startWebAuthentication(url: url)
        guard let items = URLComponents(url: callback, resolvingAgainstBaseURL: false)?.queryItems,
              let code = items.first(where: { $0.name == "code" })?.value else {
            if let error = items.first(where: { $0.name == "error" })?.value {
                throw AuthError.provider(error)
            }
            throw AuthError.noAuthorizationCode
        }

        accessToken = try await exchange(code: code, verifier: verifier)
    }

    func signOut() {
        accessToken = nil
    }

    private func startWebAuthentication(url: URL) async throws -> URL {
        try await withCheckedThrowingContinuation { continuation in
            let auth = ASWebAuthenticationSession(
                url: url,
                callbackURLScheme: "dcdsbfresh"
            ) { callbackURL, error in
                if let callbackURL {
                    continuation.resume(returning: callbackURL)
                } else {
                    continuation.resume(throwing: error ?? AuthError.cancelled)
                }
            }
            auth.presentationContextProvider = self
            auth.prefersEphemeralWebBrowserSession = false
            self.session = auth
            auth.start()
        }
    }

    private func exchange(code: String, verifier: String) async throws -> String {
        var request = URLRequest(url: URL(string:
            "https://login.microsoftonline.com/\(AppConfig.tenantID)/oauth2/v2.0/token"
        )!)
        request.httpMethod = "POST"
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")

        let body = [
            "client_id=\(Self.form(code: AppConfig.clientID))",
            "scope=\(Self.form("openid profile offline_access"))",
            "code=\(Self.form(code))",
            "redirect_uri=\(Self.form(AppConfig.redirectURI))",
            "grant_type=authorization_code",
            "code_verifier=\(Self.form(verifier))"
        ].joined(separator: "&")
        request.httpBody = body.data(using: .utf8)

        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            throw AuthError.tokenExchangeFailed
        }

        struct TokenResponse: Decodable { let access_token: String }
        return try JSONDecoder().decode(TokenResponse.self, from: data).access_token
    }

    private static func form(_ value: String) -> String {
        value.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)?
            .replacingOccurrences(of: "+", with: "%20") ?? value
    }

    private static func randomString(length: Int) -> String {
        let alphabet = Array("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789")
        return String((0..<length).compactMap { _ in alphabet.randomElement() })
    }

    private static func base64URL(_ digest: SHA256.Digest) -> String {
        Data(digest).base64EncodedString()
            .replacingOccurrences(of: "+", with: "-")
            .replacingOccurrences(of: "/", with: "_")
            .replacingOccurrences(of: "=", with: "")
    }

    enum AuthError: Error {
        case appNotConfigured, invalidURL, cancelled, noAuthorizationCode
        case provider(String), tokenExchangeFailed
    }
}

extension DCDSBAuthorization: ASWebAuthenticationPresentationContextProviding {
    nonisolated func presentationAnchor(for session: ASWebAuthenticationSession) -> ASPresentationAnchor {
        ASPresentationAnchor()
    }
}
