import Foundation

actor DCDSBAPI {
    private let baseURL: URL
    private let session: URLSession

    init(baseURL: URL = AppConfig.apiBaseURL) {
        self.baseURL = baseURL
        self.session = .shared
    }

    func profile(accessToken: String) async throws -> DCDSBProfile {
        try await get("/me", token: accessToken)
    }

    func classes(accessToken: String) async throws -> [DCDSBClass] {
        try await get("/classes", token: accessToken)
    }

    func assignments(accessToken: String) async throws -> [DCDSBAssignment] {
        try await get("/assignments", token: accessToken)
    }

    func announcements(accessToken: String) async throws -> [DCDSBAnnouncement] {
        try await get("/announcements", token: accessToken)
    }

    private func get<T: Decodable>(_ path: String, token: String) async throws -> T {
        var request = URLRequest(url: baseURL.appendingPathComponent(path))
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        let (data, response) = try await session.data(for: request)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            throw APIError.httpFailure
        }
        return try JSONDecoder.school.decode(T.self, from: data)
    }

    enum APIError: Error { case httpFailure }
}

extension JSONDecoder {
    static let school: JSONDecoder = {
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return decoder
    }()
}
