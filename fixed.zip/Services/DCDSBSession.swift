import Foundation
import SwiftUI

@MainActor
final class DCDSBSession: ObservableObject {
    @Published private(set) var isSignedIn = false
    @Published private(set) var profile: DCDSBProfile?
    @Published private(set) var classes: [DCDSBClass] = []
    @Published private(set) var assignments: [DCDSBAssignment] = []
    @Published private(set) var announcements: [DCDSBAnnouncement] = []
    @Published var errorMessage: String?

    private let auth = DCDSBAuthorization()
    private let api = DCDSBAPI()

    func signIn() async {
        do {
            try await auth.signIn()
            isSignedIn = true

            guard let token = auth.accessToken else { return }
            async let p = api.profile(accessToken: token)
            async let c = api.classes(accessToken: token)
            async let a = api.assignments(accessToken: token)
            async let n = api.announcements(accessToken: token)

            profile = try await p
            classes = try await c
            assignments = try await a
            announcements = try await n
        } catch {
            errorMessage = String(describing: error)
            isSignedIn = false
        }
    }

    func signOut() {
        auth.signOut()
        isSignedIn = false
        profile = nil
        classes = []
        assignments = []
        announcements = []
    }
}
