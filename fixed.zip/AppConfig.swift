import Foundation

enum AppConfig {
    // Replace these with values from an application registration approved for DCDSB.
    static let tenantID = "043c5d87-8370-464f-af11-0c9b9db80d82"
    static let clientID = "REPLACE_WITH_YOUR_APPROVED_APP_CLIENT_ID"

    // A custom URL scheme must be registered for the app registration.
    static let redirectURI = "dcdsbfresh://oauth/callback"

    // Replace with an approved API/integration endpoint.
    static let apiBaseURL = URL(string: "https://example.invalid/api")!
}
