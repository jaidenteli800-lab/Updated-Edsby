import SwiftUI

@main
struct DCDSBFreshApp: App {
    @StateObject private var session = DCDSBSession()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(session)
        }
    }
}
