import SwiftUI

struct ClassesView: View {
    @EnvironmentObject private var session: DCDSBSession

    var body: some View {
        NavigationStack {
            List(session.classes) { course in
                NavigationLink {
                    ClassDetailView(course: course)
                } label: {
                    VStack(alignment: .leading, spacing: 5) {
                        Text(course.name).font(.headline)
                        Text(course.teacher?.displayName ?? "Teacher unavailable")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }
                    .padding(.vertical, 5)
                }
            }
            .navigationTitle("Classes")
        }
    }
}

struct ClassDetailView: View {
    let course: DCDSBClass

    var body: some View {
        List {
            Section("Course") {
                LabeledContent("Subject", value: course.subject ?? "—")
                LabeledContent("Room", value: course.room ?? "—")
                LabeledContent("Teacher", value: course.teacher?.displayName ?? "—")
            }

            Section("Students · \(course.students.count)") {
                ForEach(course.students) { student in
                    HStack(spacing: 12) {
                        Circle()
                            .fill(.indigo.opacity(0.12))
                            .frame(width: 38, height: 38)
                            .overlay {
                                Text(initials(student.displayName))
                                    .font(.caption.bold())
                                    .foregroundStyle(.indigo)
                            }

                        Text(student.displayName)
                    }
                }
            }
        }
        .navigationTitle(course.name)
        .navigationBarTitleDisplayMode(.inline)
    }

    private func initials(_ name: String) -> String {
        name.split(separator: " ").prefix(2).compactMap { $0.first.map(String.init) }.joined()
    }
}
