import SwiftUI

struct DashboardView: View {
    @EnvironmentObject private var session: DCDSBSession

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    Text(greeting)
                        .font(.largeTitle.bold())

                    if let profile = session.profile {
                        Text(profile.schoolName ?? "DCDSB")
                            .foregroundStyle(.secondary)
                    }

                    HStack(spacing: 14) {
                        StatCard(title: "Classes", value: "\(session.classes.count)", icon: "books.vertical.fill")
                        StatCard(title: "To do", value: "\(session.assignments.filter { !$0.completed }.count)", icon: "checkmark.circle.fill")
                    }

                    Text("Your classes")
                        .font(.title2.bold())

                    ForEach(session.classes.prefix(4)) { course in
                        NavigationLink {
                            ClassDetailView(course: course)
                        } label: {
                            CourseCard(course: course)
                        }
                        .buttonStyle(.plain)
                    }

                    Text("Announcements")
                        .font(.title2.bold())

                    ForEach(session.announcements.prefix(3)) { item in
                        VStack(alignment: .leading, spacing: 7) {
                            Text(item.title).font(.headline)
                            Text(item.body).foregroundStyle(.secondary).lineLimit(3)
                        }
                        .padding()
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 18))
                    }
                }
                .padding()
            }
            .navigationTitle("DCDSB")
        }
    }

    private var greeting: String {
        guard let name = session.profile?.displayName else { return "Welcome" }
        return "Hi, \(name.components(separatedBy: " ").first ?? name)"
    }
}

struct StatCard: View {
    let title: String
    let value: String
    let icon: String

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Image(systemName: icon).foregroundStyle(.indigo)
            Text(value).font(.title.bold())
            Text(title).foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding()
        .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 18))
    }
}

struct CourseCard: View {
    let course: DCDSBClass

    var body: some View {
        HStack(spacing: 14) {
            RoundedRectangle(cornerRadius: 14)
                .fill(.indigo.opacity(0.12))
                .frame(width: 52, height: 52)
                .overlay {
                    Image(systemName: "book.fill").foregroundStyle(.indigo)
                }

            VStack(alignment: .leading, spacing: 4) {
                Text(course.name).font(.headline)
                Text(course.teacher?.displayName ?? "Teacher unavailable")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }

            Spacer()

            Image(systemName: "chevron.right")
                .foregroundStyle(.tertiary)
        }
        .padding()
        .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 18))
    }
}
