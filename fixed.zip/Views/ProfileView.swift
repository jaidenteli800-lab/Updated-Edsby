import SwiftUI

struct ProfileView: View {
    @EnvironmentObject private var session: DCDSBSession

    var body: some View {
        NavigationStack {
            List {
                if let profile = session.profile {
                    Section {
                        VStack(spacing: 12) {
                            Circle()
                                .fill(.indigo.opacity(0.12))
                                .frame(width: 82, height: 82)
                                .overlay {
                                    Image(systemName: "person.fill")
                                        .font(.system(size: 34))
                                        .foregroundStyle(.indigo)
                                }
                            Text(profile.displayName)
                                .font(.title3.bold())
                            Text(profile.email ?? "")
                                .foregroundStyle(.secondary)
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 12)
                    }

                    Section("School") {
                        LabeledContent("School", value: profile.schoolName ?? "—")
                        LabeledContent("Role", value: profile.role ?? "—")
                    }
                }

                Section {
                    Button("Sign Out", role: .destructive) {
                        session.signOut()
                    }
                }
            }
            .navigationTitle("Profile")
        }
    }
}
