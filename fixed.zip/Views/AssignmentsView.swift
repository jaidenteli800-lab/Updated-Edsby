import SwiftUI

struct AssignmentsView: View {
    @EnvironmentObject private var session: DCDSBSession

    var body: some View {
        NavigationStack {
            List(session.assignments) { item in
                HStack(spacing: 14) {
                    Image(systemName: item.completed ? "checkmark.circle.fill" : "circle")
                        .foregroundStyle(item.completed ? .green : .indigo)
                    VStack(alignment: .leading, spacing: 4) {
                        Text(item.title).font(.headline)
                        Text(item.courseName).font(.subheadline).foregroundStyle(.secondary)
                        if let date = item.dueDate {
                            Text(date.formatted(date: .abbreviated, time: .omitted))
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                    }
                }
                .padding(.vertical, 4)
            }
            .navigationTitle("Work")
        }
    }
}
