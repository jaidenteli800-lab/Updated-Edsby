import SwiftUI

struct LoginView: View {
    @EnvironmentObject private var session: DCDSBSession
    @State private var loading = false

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [.blue.opacity(0.95), .indigo],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()

            VStack(spacing: 26) {
                Image(systemName: "graduationcap.fill")
                    .font(.system(size: 62))
                    .foregroundStyle(.white)

                VStack(spacing: 8) {
                    Text("DCDSB Fresh")
                        .font(.system(size: 38, weight: .bold, design: .rounded))
                        .foregroundStyle(.white)
                    Text("Your school, redesigned.")
                        .font(.title3)
                        .foregroundStyle(.white.opacity(0.85))
                }

                Spacer()

                Button {
                    loading = true
                    Task {
                        await session.signIn()
                        loading = false
                    }
                } label: {
                    HStack {
                        if loading { ProgressView().tint(.primary) }
                        Text(loading ? "Opening DCDSB sign-in…" : "Sign in with DCDSB")
                            .fontWeight(.semibold)
                    }
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(.white, in: RoundedRectangle(cornerRadius: 18))
                    .foregroundStyle(.indigo)
                }
                .disabled(loading)

                Text("Your password is entered only on the Microsoft sign-in page.")
                    .font(.footnote)
                    .multilineTextAlignment(.center)
                    .foregroundStyle(.white.opacity(0.75))
            }
            .padding(28)
        }
    }
}
