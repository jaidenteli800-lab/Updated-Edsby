import SwiftUI

struct MainTabView: View {
    var body: some View {
        TabView {
            DashboardView()
                .tabItem { Label("Home", systemImage: "house.fill") }
            ClassesView()
                .tabItem { Label("Classes", systemImage: "person.3.fill") }
            AssignmentsView()
                .tabItem { Label("Work", systemImage: "checklist") }
            ProfileView()
                .tabItem { Label("Profile", systemImage: "person.crop.circle") }
        }
        .tint(.indigo)
    }
}
